Blumix-Edge
===========

Blumix-Edge (daily builds): A Minimal Blue-ish theme for GTK3
--------------------------------------------------------------

This repo may contain errors and not properly configured files. 

This started as a Mod for Numix Gtk3 Theme, and now evolved to this. A new proposal, rounded, clear and fresh.  


