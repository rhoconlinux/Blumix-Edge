Copy "scrollbars" into "/usr/share/themes/Ambiance/gtk-2.0/" directory,
and replace "/usr/share/themes/Ambiance/gtk-2.0/apps/ff.rc" with that one provided.

Tested on Oneiric Ocelot
